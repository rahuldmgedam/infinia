 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml" lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<title>Alstone - Interior Building Products Manufacturers | WPC Manufacturer in Delhi, India</title>

<meta name="title" content="Alstone - Interior Building Products Manufacturers | WPC Manufacturer in Delhi, India">
<meta name="description" content="Alstone WPC has a highly versatile material that helps interior building product manufacturers beautify spaces. The WPC manufacturer in India, offers high quality products that are termite proof, water resistant, and highly sustainable.">
<meta name="keywords" content="Wpc manufacturer in india,Alstone wpc,Wpc manufacturer in Delhi,interior building products manufacturers">
<meta name="google-site-verification" content="BC0K-VaZn1JoyCvMdD0jmEU080GeKiyz7HArvuPpMdo" />

<link rel="canonical" href="https://www.alstoneindia.in/signals/iwl.js" />

<link rel="icon" href="https://www.alstoneindia.in/public/front/images/fav.png" type="image/x-icon"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Owl Stylesheets -->
<link rel="stylesheet" href="https://www.alstoneindia.in/public/front/css/owl.carousel.min.css">
<link rel="stylesheet" href="https://www.alstoneindia.in/public/front/css/owl.theme.default.min.css">

<!-- main Stylesheets -->
<link rel="stylesheet" type="text/css" href="https://www.alstoneindia.in/public/front/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://www.alstoneindia.in/public/front/css/animation.css">
<link rel="stylesheet" type="text/css" href="https://www.alstoneindia.in/public/front/css/aos.css">
<link rel="stylesheet" type="text/css" href="https://www.alstoneindia.in/public/front/css/jquery.mCustomScrollbar.css">
<link rel="stylesheet" href="https://www.alstoneindia.in/public/front/css/jquery.fancybox.min.css" type="text/css">
<link rel="stylesheet" type="text/css" href="https://www.alstoneindia.in/public/front/css/style.css">

<!-- main Javascript -->
<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/owl.carousel.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/jquery.popupoverlay.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-J8KRQQ0MQL"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-J8KRQQ0MQL');
</script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-54D993X');</script>
<!-- End Google Tag Manager -->


<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '974795536431428');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=974795536431428&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-203091400-2">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-203091400-2');
</script>


<!--Ritik's code-->

<script type="text/javascript">
    (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
    })(window, document, "clarity", "script", "k4r03b72an");
</script>

</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-54D993X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!-- Header Inner -->

<div class="container-fluid hdr-top">
        <div class="row">
 <div class="col-sm-6"><a class="cl-action" href="tel:9205666837"> <i class="fa fa-phone claction"></i> 9205666837 </a> <span style="color:#fff;"> | </span><a class="cl-action" href="mailto:csd1.wpc@alstoneindia.in"><i class="fa fa-envelope claction"></i>csd1.wpc@alstoneindia.in</a></div>

 <div class="col-sm-6">
    <div class="social-top">
<a href="https://www.facebook.com/AlstoneIndustriesPrivateLimited"><i class="fa fa-facebook clr"></i></a>
<a href="https://twitter.com/AlstoneIndustry"><i class="fa fa-twitter clr"></i></a>
<a href="https://www.instagram.com/alstone.industries/"><i class="fa fa-instagram clr"></i></a>
<a href="https://www.linkedin.com/company/alstone-wpc-and-silicone"><i class="fa fa-linkedin clr"></i></a>
<a href="https://www.youtube.com/channel/UCYPrfoTcL1WQMBPj2_Go3Qw"><i class="fa fa-youtube clr"></i></a>
 </div>
</div>

        </div>
    </div>
<div class="headerinr" id="myHeader">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="logoinr" data-aos="fade-right"><a href="https://www.alstoneindia.in/home"><img src="https://www.alstoneindia.in/public/front/images/black-logo.png" /></a></div>
            </div>
            <div class="col-md-9">
                <div class="logoinrcal" data-aos="fade-left" data-aos-easing="ease" data-aos-delay="400">
                    <div class="grt-menu-right">
                        <nav>
                            <button class="grt-mobile-button"><span class="line1"></span><span class="line2"></span><span class="line3"></span></button>
                            <ul class="grt-menu">
                                <li ><a href="https://www.alstoneindia.in/home">Home</a></li>
                               <li ><a href="https://www.alstoneindia.in/about">About us</a></li>
                                <li>
                                    <a href="JavaScript:Void(0);">Products</a>
                                  <div class="mainNav dropdown-list">
              <ul>
                 <li><a href="#">WPC Doors and Window Frames</a></li>

                                                                                            <li><a href="#">Silicone Foam </a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/fr-pu-foam">FR Pu Foam  </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/silicone-foam-mf-1">Silicone Foam MF1 </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                    <li><a href="#">Pu Sealant & Foam</a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/alstone-pu-sealant-221">PU Sealant 221 </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/Alstone-PU-Sealant-265">Pu Sealant-265 </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/alstone-pu-foam-1k">PU Foam 1K </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                                                  <li><a href="https://www.alstoneindia.in/product/alstone-stixLam-special-adhesive">Siliconised Special Adhesive glue </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/pre-laminated-door-and-chaukhat-combo">Wpc Pre Laminated Door and Chaukhat Combo  </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/wood-polymer-composite-sheet">WPC Board </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/wpc-doors-and-window-frames">WPC Frame </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/wpc-acoustic-wall-panel">WPC Acoustic Wall Panel </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/alstone-toilet-cubicals">Alstone Wpc Toilet Cubicals </a></li> 
                                                                                                                                                 <li><a href="#">WPC Doors</a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/solid-plain-door">Solid Plain  Door </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/routed-doors">Routed Doors </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/wpc-tubular-hollow-door">WPC tubular hollow DOOR </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/Pre-Laminated-Designer-Doors">Pre Laminated Designer Doors </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                                                  <li><a href="https://www.alstoneindia.in/product/alstone-silicone-grease">Silicone Grease </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/silicone">Silicone Sealant </a></li> 
                                                                                                                                                                               <li><a href="https://www.alstoneindia.in/product/wpc-modular-kitchen">WPC Modular Kitchen </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/wpc-art-jaali">WPC Art Jaali </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/spc-flooring">WPC Flooring </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/18mm-pre-laminated-designer-wpc"> 18MM Pre Laminated Designer WPC </a></li> 
                                                          <li><a href="https://www.alstoneindia.in/product/wpc-shuttering-ply"> WPC Shuttering Ply  </a></li> 
                                                                                                                                                 <li><a href="#">Silicone Sealant Series </a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/alstone-color-silicone-sealant">Alstone Color Silicone WS -789 </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/alstone-wpc-fix">WPC Fix  </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/wpc-pvc-adhesive-fix">WPC/PVC Adhesive Fix  </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/gP-100-alstone-general-purpose-silicone-sealants">GP 100 Alstone General Purpose Silicone Sealants </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/general-purpose-silicone-sealants">General Purpose Silicone Sealants </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/neutral-silicone-sealants">Neutral Silicone Sealants </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/weather-silicone-color-sealant-789">Weather Silicone Sealant- 789 </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/structural-silicone-sealant">Structural Silicone Sealant </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/non-bleeding-silicone-sealant">NON BLEEDING SILICONE SEALANT </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/silicone-mold-release-agents">Silicone Mold Release Agents </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/Alstone-Silicone-Emulsion">Alstone Silicone Emulsion </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/Alstone-Silicone-Fluids">Alstone Silicone Fluids </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/amino-fluid-amino-functional-silicone-fluid">Amino Fluid (Amino Functional) Silicone Fluid </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/alstone-silicone-antifoams-defoamers">Alstone Silicone Antifoams/Defoamers </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                    <li><a href="#">MS ADHESIVE</a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/stone-tite">Stone Tite </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/stotil-fix">﻿STOTIL FIX </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/stix-all-adhesive">StixAll Adhesive </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/mirror-fix-100">Mirror Fix 100 </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/stixall-tube-85g">StixAll Tube  </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                    <li><a href="#">2 PART SILICONE SEALANT</a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/insulating-glass-silicone-sealant">Insulating Glass Silicone Sealant </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/structural-glazing-silicone-sealant">Structural Glazing Silicone Sealant </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                    <li><a href="#">SILICONE FLUIDS</a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/pdms-silicone-oils">PDMS Silicone Oils </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/oh-polymer">OH Polymer </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                                                                                                    <li><a href="#">CYCLICS</a>
                                <ul>
                                                                 
                                <a href="https://www.alstoneindia.in/product/dimethylsiloxanecyclics-dmc">Dimethylsiloxanecyclics DMC </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/octamethylcyclotetrasiloxaned4">Octamethylcyclotetrasiloxane(D4) </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/hexamethylcyclotrisiloxaned3">Hexamethylcyclotrisiloxane(D3) </a>
                                </li> 
                                                                 
                                <a href="https://www.alstoneindia.in/product/decamethylcyclopentasiloxaned5">Decamethylcyclopentasiloxane(D5) </a>
                                </li> 
                                 
                                </ul>
                            </li>
                                            

                <!--  <li><a href="https://www.alstoneindia.in/product/wood-polymer-composite-sheet">Wood Polymer Composite Sheet </a></li>
                 <li><a href="https://www.alstoneindia.in/product/wpc-doors-and-window-frames">WPC Doors And Window Frames </a></li>
                 <li class="has-subnav">
                    <a href="#">WPC Doors</a>
                    <span class="accordion-btn-wrap">
                        <span class="accordion-btn accordion-collapsed"><i class="fa fa-angle-down"></i></span>
                        <span class="accordion-btn accordion-expanded"><i class="fa fa-angle-up"></i></span>
                    </span>
                    <ul style="display: none;">
                       
                       <a href="https://www.alstoneindia.in/product/solid-plain-door">Solid Plain  Door </a>
                       <a href="https://www.alstoneindia.in/product/routed-doors">Routed Doors </a>
                       <a href="https://www.alstoneindia.in/product/2d-3d-doors">2D/3D Doors </a>
                       <a href="https://www.alstoneindia.in/product/Pre-Laminated-Designer-Doors">Pre Laminated Designer Doors </a>
                    </ul>
                 </li>
                 <li><a href="https://www.alstoneindia.in/product/wpc-art-jaali">WPC Art Jaali </a></li>
                 <li><a href="https://www.alstoneindia.in/product/spc-flooring">SPC Flooring </a></li>
                   <li><a href="https://www.alstoneindia.in/product/mm-pvc-laminate">1 Mm PVC Laminate </a></li>
                 <li><a href="https://www.alstoneindia.in/product/3mm-pvc-wall-cladding">3mm Pvc Wall Cladding </a></li>
                 <li><a href="https://www.alstoneindia.in/product/18mm-pre-laminated-designer-wpc"> 18MM Pre Laminated Designer WPC </a></li>
                 <li><a href="https://www.alstoneindia.in/product/water-proof-ply">Water Proof Ply </a></li>
                 <li><a href="https://www.alstoneindia.in/product/wpc-hollow-formwork"> WPC Hollow Formwork Sheet </a></li>
                 <li><a href="https://www.alstoneindia.in/product/silicone-foam-mf-1"> Silicone Foam MF 1 </a></li>
                 <li><a href="https://www.alstoneindia.in/product/silicone">Silicone </a></li>
                 <li class="has-subnav">
                    <a href="#">SILICONE SEALANTS </a>
                    <span class="accordion-btn-wrap"><span class="accordion-btn accordion-collapsed"><i class="fa fa-angle-down"></i></span><span class="accordion-btn accordion-expanded" style="display: none; width: 100%; line-height: 28px; height: 28px;"><i class="fa fa-angle-up"></i></span></span>
                    <ul style="display: none;">
                       <a href="https://www.alstoneindia.in/product/general-purpose-silicone-sealants">General Purpose Silicone Sealants </a>
                       <a href="https://www.alstoneindia.in/product/neutral-silicone-sealants">Neutral Silicone Sealants </a>
                       <a href="https://www.alstoneindia.in/product/weather-silicone-color-sealant-789">Weather Silicone Sealant- 789 </a>
                       <a href="https://www.alstoneindia.in/product/structural-silicone-sealant">Structural Silicone Sealant </a>
                       <a href="https://www.alstoneindia.in/product/non-bleeding-silicone-sealant">Non Bleeding Silicone Sealant </a>
                    </ul>
                 </li>
                 <li class="has-subnav">
                    <a href="#">MS ADHESIVE </a>
                    <span class="accordion-btn-wrap"><span class="accordion-btn accordion-collapsed"><i class="fa fa-angle-down"></i></span><span class="accordion-btn accordion-expanded"><i class="fa fa-angle-up"></i></span></span>
                    <ul style="display: none;">
                       <a href="https://www.alstoneindia.in/product/stix-all-adhesive">Stix All Adhesive </a>
                       <a href="https://www.alstoneindia.in/product/mirror-fix-100">Mirror Fix 100 </a>
                    </ul>
                 </li>
                 <li class="has-subnav">
                    <a href="#">2 PART SILICONE SEALANT </a>
                    <span class="accordion-btn-wrap"><span class="accordion-btn accordion-collapsed"><i class="fa fa-angle-down"></i></span><span class="accordion-btn accordion-expanded"><i class="fa fa-angle-up"></i></span></span>
                    <ul style="display: none;">
                       <a href="https://www.alstoneindia.in/product/insulating-glass-silicone-sealant">Insulating Glass Silicone Sealant </a>
                       <a href="https://www.alstoneindia.in/product/structural-glazing-silicone-sealant">Structural Glazing Silicone Sealant </a>
                    </ul>
                 </li>
                 <li class="has-subnav">
                    <a href="#">SILICONE FLUIDS </a>
                    <span class="accordion-btn-wrap"><span class="accordion-btn accordion-collapsed"><i class="fa fa-angle-down"></i></span><span class="accordion-btn accordion-expanded"><i class="fa fa-angle-up"></i></span></span>
                    <ul style="display: none;">
                       <a href="https://www.alstoneindia.in/product/pdms-silicone-oils">PDMS Silicone Oils </a>
                       <a href="https://www.alstoneindia.in/product/oh-polymer">OH Polymer </a>
                    </ul>
                 </li>
                 <li class="has-subnav">
                    <a href="#">CYCLICS </a>
                    <span class="accordion-btn-wrap"><span class="accordion-btn accordion-collapsed"><i class="fa fa-angle-down"></i></span><span class="accordion-btn accordion-expanded"><i class="fa fa-angle-up"></i></span></span>
                    <ul style="display: none;">
                       <a href="https://www.alstoneindia.in/product/dimethylsiloxanecyclics-dmc">Dimethylsiloxanecyclics DMC </a>
                       <a href="https://www.alstoneindia.in/product/octamethylcyclotetrasiloxaned4">Octamethylcyclotetrasiloxane(D4) </a>
                       <a href="https://www.alstoneindia.in/product/hexamethylcyclotrisiloxaned3">Hexamethylcyclotrisiloxane(D3) </a>
                       <a href="https://www.alstoneindia.in/product/decamethylcyclopentasiloxaned5">Decamethylcyclopentasiloxane(D5) </a>
                    </ul>
                 </li>  -->
              </ul>
     </div>       

                                </li>
                                <li ><a href="https://www.alstoneindia.in/media">Media and events </a></li>
                                <li ><a href="https://www.alstoneindia.in/careers">Careers </a></li>
                                <li><a href="https://www.alstoneindia.in/blog" target="_blank">Blog </a></li>
                                <li ><a href="https://www.alstoneindia.in/dealerlocator">Dealer Locator </a></li>
                               <!-- <li><a href="#">Credentials </a></li>-->                
                            </ul>
                        </nav>
                        <div class="menurightbtn"><a href="https://www.alstoneindia.in/contact">Contact Us</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>




<div class="breadcum">
    <div class="breadcum-inner">
        <ul class="breadcrumb" style="margin-bottom:0px">
            <li class="completed"><a href="https://www.alstoneindia.in/home">Home</a></li>
            <li class="active">/signals/iwl.js</li>
        </ul>
</div>
</div> 

<style>.breadcrumb > li + li::before {
  padding: 0 5px;
  color: #ccc;
  content: "/\00a0";
  display: none;
}
.cl-action:hover {
  color: #fff;
}
</style><div class="about-sec">    <div class="container-fluid">        <div class="row">            <div class="col-md-6">                <div class="banner-title" data-aos="fade-right" data-aos-easing="ease" data-aos-delay="700">                    <h3>404 <br>                   <b>Page not found</b> </h3>                </div>            </div>                       <div class="col-md-6">                <div class="banner-title" data-aos="fade-right" data-aos-easing="ease" data-aos-delay="1200">                    <img src="images/img04.png" alt="">                    <h4> 					 The content you are looking for is not found click here to go back to the website:    <a href="https://www.alstoneindia.in/">Here</a></h4>                </div>            </div>        </div>     </div></div>

 <!-- Footer Inner -->

<div class="footeriner">
	<div class="fotertop">
    	<div class="container">
        	<div class="row">
            	<div class="col-md-12">
                    <div class="fotlogo" data-aos="zoom-in" data-aos-delay="800"><a href="https://www.alstoneindia.in/home"><img src="https://www.alstoneindia.in/public/front/images/black-logo.png" /></a></div>
                    <h4>Connect with Us</h4>
                    <div class="fotsub" data-aos="fade-right" data-aos-easing="ease" data-aos-delay="400">
                    	<form action="https://www.alstoneindia.in/home/newsletter" id="newsletter" name="newsletter" enctype="multipart/form-data" method="post" accept-charset="utf-8">
                            <input type="email" name="email" placeholder="Enter your E-mail" />
                            <input type="text" name="phone" placeholder="Enter Your Number" />
                            <button><i class="fa fa-long-arrow-right"></i></button>
                        </form>
                    </div>

<div class="fotlink" data-aos="fade-down" data-aos-easing="ease" data-aos-delay="1200">
                    	<h4>Our Address</h4>

                    	<div id="" class="vcard">

 <div class="adr">
  <div class="street-address">2E/7 Block E 2 Jhandewalan Extension Jhandewalan</div>
  <span class="locality">New Delhi</span>
, 
  <span class="region">Delhi</span>
, 
  <span class="postal-code">110055 </span>

  <span class="country-name">India</span>

 </div>
</div>
                        
                    </div>

                    <div class="fotlink" data-aos="fade-down" data-aos-easing="ease" data-aos-delay="1200">


                    	<h4>Useful links</h4>
                        <ul>
                        	<li><a href="https://www.alstoneindia.in/contact">Contact Us</a></li>
                            <li><a href="https://www.alstoneindia.in/page/faq">FAQ</a></li>
                            <li><a href="https://www.alstoneindia.in/page/terms">T&#38;C </a></li>
                            <li><a href="https://www.alstoneindia.in/product/wood-polymer-composite-sheet">WPC Wood Polymer Composite</a></li>
                            <li><a href="https://www.alstoneindia.in/product/silicone"> Silicone</a></li>
                             <li><a href="https://blogalstone.blogspot.com/" target="_blank">Blog</a></li> 
                            <li><a href="https://www.alstoneindia.in/page/privacy">Policy</a></li>
                        </ul>
                    </div>

         <div class="fotlink" data-aos="fade-down" data-aos-easing="ease" data-aos-delay="1200">
                    	<h4>Quick links</h4>
                        <ul>
                        	<li><a href="https://www.alstoneindia.in/product/alstone-silicone-grease">Alstone Silicone Grease</a></li>
                            <li><a href="https://www.alstoneindia.in/product/pre-laminated-door-and-chaukhat-combo">Pre Laminated Door and Chaukhat Combo</a></li>
                            <li><a href="https://www.alstoneindia.in/product/silicone">silicone</a></li>
                            <li><a href="https://www.alstoneindia.in/product/solid-plain-door">Solid Plain Door</a></li>
                            <li><a href="https://www.alstoneindia.in/product/structural-silicone-sealant">Structural Silicone Sealant</a></li>
                            <li><a href="https://www.alstoneindia.in/product/weather-silicone-color-sealant-789">Weather Silicone Color Sealant 789</a></li>
                            <li><a href="https://www.alstoneindia.in/product/wood-polymer-composite-sheet">Wood Polymer Composite Sheet</a></li>
                            <li><a href="https://www.alstoneindia.in/product/wpc-art-jaali">Wpc Art Jaali</a></li>
                            <li><a href="https://www.alstoneindia.in/product/wpc-doors-and-window-frames">Wpc Doors And Window Frames</a></li>
			    <li><a href="https://www.alstoneindia.in/product/wpc-modular-kitchen">WPC Modular Kitchen</a></li>
                        </ul>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <div class="foterbot">
    	<div class="container-fluid">
        	<div class="row">
            	<div class="col-md-4">
                	<div class="fotbotfolow">
                        Follow Us <a href="https://www.facebook.com/AlstoneIndustriesPrivateLimited" target="_blank"><i class="fa fa-facebook"></i></a> 
                        <a href="https://twitter.com/AlstoneIndustry" target="_blank"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com/alstone.industries/" target="_blank"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.linkedin.com/company/alstone-wpc-and-silicone" target="_blank"><i class="fa fa-linkedin"></i></a>
                        <a href="https://www.youtube.com/channel/UCYPrfoTcL1WQMBPj2_Go3Qw" target="_blank"><i class="fa fa-youtube-play"></i></a>                            
                    </div>
                </div>
				
                <div class="col-md-8">
				
                	<div class="fotrigtlink">
                    	<a href="https://www.alstoneindia.in/cmspages/sitemap">Sitemap</a> / <a href="https://www.alstoneindia.in/page/privacy">Privacy Policy</a> / <a href="https://www.alstoneindia.in/page/terms">Terms & Conditions</a> © 2022 ALSTONE INDUSTRIES PVT. LTD. - All Rights Reserved
                    	<span class="made-in-india"><img src="https://www.alstoneindia.in/public/front/images/MADE-IN-INDIA.jpg" alt=""></span>
                    </div>
                     
                </div>
                <div class="col-md-12 text-center" style="border-top: 1px solid #eee; padding-top: 5px; margin-top: 5px;">
                	<p style="font-size: 12px; margin-bottom: 0;">Designed & Developed by <a href="https://www.alstoneindia.in/" target="_blank"><img style="margin-left:5px;height: 15px; width: auto;" src="https://alstoneindia.in/public/front/images/nvd-logo.png"></a></p>
                </div>
            </div>
        </div>
    </div>
</div>
  <script src="https://www.alstoneindia.in/public/admin/js/jquery.validate.js"></script>
 <script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/common.js"></script>

 
<div id="fadeandscale" class="vidopop" style="display:none;">
    <div class="fadeandscale_close vidopopclse">X</div>
    <div class="vidopopfrme"><iframe width="100%" height="300px" src="https://www.youtube.com/embed/_3qejpNEh2E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
</div>




<style>
#fadeandscale {
    -webkit-transform: scale(0.8);
       -moz-transform: scale(0.8);
        -ms-transform: scale(0.8);
            transform: scale(0.8);
}
.popup_visible #fadeandscale {
    -webkit-transform: scale(1);
       -moz-transform: scale(1);
        -ms-transform: scale(1);
            transform: scale(1);
}
.error{color:red !important; }
</style>


<!-- Google  Fonts -->
<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Mukta+Vaani:400,800&display=swap" rel="stylesheet">

<a href="#" class="scrollup">Scroll To Top</a>

<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/highlight.min.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/aos.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/grt-responsive-menu.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/navAccordion.min.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/jquery.mCustomScrollbar.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/jquery.fancybox.min.js"></script>
<script type="text/javascript" src="https://www.alstoneindia.in/public/front/js/main.js"></script>


</body>
</html>
 
<!-- Footer -->
